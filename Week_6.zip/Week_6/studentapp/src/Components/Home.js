import React, { Component } from "react";

export class Home extends Component {
  render() {
    return (
      <div>
        <h3>Welcome to the home page of student management portal</h3>
      </div>
    );
  }
}
