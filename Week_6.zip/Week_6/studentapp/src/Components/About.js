import React, { Component } from "react";

export class About extends Component {
  render() {
    return (
      <div>
        <h3>Welcome to the About page of student management portal</h3>
      </div>
    );
  }
}
